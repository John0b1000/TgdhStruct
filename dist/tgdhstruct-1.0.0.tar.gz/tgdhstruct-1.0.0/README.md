# Python Package: tgdhstruct
This repo contains a Python package for TGDH implementation.
