# Python Package: tgdhstruct
This repo contains a Python package for TGDH implementation.
## Installation
Build the source distribution:
```
python3 setup.py sdist --formats=gztar
```
Use pip to install:
```
pip3 install <filename>.tar.gz
```
